module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
