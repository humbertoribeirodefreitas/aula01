import Image from 'react'

export default function app(){
  return(
    <>
    <p>cfb cursos</p>
    <br />
    <p>cursos de react</p>
 </>   
)
}